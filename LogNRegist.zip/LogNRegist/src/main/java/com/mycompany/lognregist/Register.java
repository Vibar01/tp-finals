
package com.mycompany.lognregist;

/**
 *
 * @author MariaRufalethVibar
 */
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Register extends javax.swing.JFrame {


    String usersFilePath = "C:\\Users\\Maria Rufaleth Vibar\\Desktop\\TPVibar\\User.txt";
    ArrayList<String> all_usernames = new ArrayList<>();
    Map<String, String> usernamesAndPasswords = new HashMap<>();
    MessageFrame mesframe = new MessageFrame();
    
    public Register() {
        initComponents();
        
        addPlaceholder(jTextField1);
        addPlaceholder(jTextField2);
        addPlaceholder(jTextField3);
        addPlaceholder(jPasswordField1);
        addPlaceholder(jPasswordField2);
        this.setLocationRelativeTo(null);
        
        getUsers();
    }
    
    
    //gets data and reads the file
    public void getUsers(){
        File file = new File(usersFilePath);
        String username = "";
        String password = "";
        
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            //reads the file, line by line
            Object[] lines = br.lines().toArray();
            for(int i = 0; i < lines.length; i++)
            {
                //split the row into two 
                //one for name of the fields
                //and the other for the value
                String[] row = lines[i].toString().split(": ");
                if(row[0].equals("Username"))
                {
                    //if its the username field, gets the username
                    username = row[1];
                    // add the username to the array
                    all_usernames.add(username);
                }
                else if(row[0].equals("Password"))
                {
                    //for the password field, gets the password
                    password = row[1];
                }
                if(!username.equals("") && !password.equals(""))
                {
                    //adds the username n pass into the hashmap
                    usernamesAndPasswords.put(username, password);
                }
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Checks username if it exists
    public boolean checkUsername(String use)
    {
        boolean exists = false;
        
        for(String username: all_usernames)
        {
            if(username.equals(use))
            {
                exists = true;
            }
        }
        
        return exists;
    }
    
    
     public void addPlaceholder(JTextField textField){
        Font font = textField.getFont();
        font = font.deriveFont(Font.ITALIC);
        textField.setFont(font);
        textField.setForeground(Color.gray);
    }
    
    public void removePlaceholder(JTextField textField){
        Font font = textField.getFont();
        font = font.deriveFont(Font.PLAIN);
        textField.setFont(font);
        textField.setForeground(Color.black);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jCheckBox2 = new javax.swing.JCheckBox();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Sitka Heading", 0, 24)); // NOI18N
        jLabel1.setText("Create an Account");

        jTextField1.setText("Full Name");
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });

        jTextField3.setText("Email");
        jTextField3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField3FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField3FocusLost(evt);
            }
        });

        jTextField2.setText("Username");
        jTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField2FocusLost(evt);
            }
        });

        jPasswordField1.setText("password");
        jPasswordField1.setEchoChar('\u0000');
        jPasswordField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPasswordField1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPasswordField1FocusLost(evt);
            }
        });

        jPasswordField2.setText("confirm password");
        jPasswordField2.setEchoChar('\u0000');
        jPasswordField2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPasswordField2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPasswordField2FocusLost(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setText("Create");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jCheckBox2.setText("show password");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton2.setText("Back to Login");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(106, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(116, 116, 116))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jCheckBox2)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField2)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField3)
                            .addComponent(jPasswordField1)
                            .addComponent(jPasswordField2, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel1)
                .addGap(25, 25, 25)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox2)
                .addGap(35, 35, 35)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField2FocusGained
        //username placeholder
         if(jTextField2.getText().trim().equals("Username")){
            jTextField2.setText("");
            jTextField2.requestFocus();
            removePlaceholder(jTextField2);
        }
    }//GEN-LAST:event_jTextField2FocusGained

    private void jTextField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusGained
        //Full name placeholder
         if(jTextField1.getText().trim().equals("Full Name")){
            jTextField1.setText("");
            jTextField1.requestFocus();
            removePlaceholder(jTextField1);
        }
    }//GEN-LAST:event_jTextField1FocusGained

    private void jTextField3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField3FocusGained
        //email placeholder
         if(jTextField3.getText().trim().equals("Email")){
            jTextField3.setText("");
            jTextField3.requestFocus();
            removePlaceholder(jTextField3);
        }
    }//GEN-LAST:event_jTextField3FocusGained

    private void jPasswordField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField1FocusGained
        //password placeholder
         if(jPasswordField1.getText().trim().equals("password")){
            jPasswordField1.setText("");
            jPasswordField1.requestFocus();
            jPasswordField1.setEchoChar('*');
            removePlaceholder(jPasswordField1);
        }
    }//GEN-LAST:event_jPasswordField1FocusGained

    private void jPasswordField2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField2FocusGained
        //password placeholder
          if(jPasswordField2.getText().trim().equals("confirm password")){
            jPasswordField2.setText("");
            jPasswordField2.requestFocus();
            jPasswordField2.setEchoChar('*');
            removePlaceholder(jPasswordField2);
        }
    }//GEN-LAST:event_jPasswordField2FocusGained

    private void jTextField2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField2FocusLost
        //placehodler
         if(jTextField2.getText().trim().equals("")){
            addPlaceholder(jTextField2);
            jTextField2.setText("Username");
        }
    }//GEN-LAST:event_jTextField2FocusLost

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        //placehodler
         if(jTextField1.getText().trim().equals("")){
            addPlaceholder(jTextField1);
            jTextField1.setText("Full Name");
        }
    }//GEN-LAST:event_jTextField1FocusLost

    private void jTextField3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField3FocusLost
        //placeholder
         if(jTextField3.getText().trim().equals("")){
            addPlaceholder(jTextField3);
            jTextField3.setText("Email");
        }
    }//GEN-LAST:event_jTextField3FocusLost

    private void jPasswordField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField1FocusLost
        //placeholder
        if(jPasswordField1.getText().trim().equals("")){
            addPlaceholder(jPasswordField1);
            jPasswordField1.setText("password");
            jPasswordField1.setEchoChar((char)0);
        }
    }//GEN-LAST:event_jPasswordField1FocusLost

    private void jPasswordField2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordField2FocusLost
        //placeholder
        if(jPasswordField2.getText().trim().equals("")){
            addPlaceholder(jPasswordField2);
            jPasswordField2.setText("confirm password");
            jPasswordField2.setEchoChar((char)0);
        }
    }//GEN-LAST:event_jPasswordField2FocusLost

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        //show password
        if(jCheckBox2.isSelected()){
            jPasswordField1.setEchoChar((char)0);
            jPasswordField2.setEchoChar((char)0);
        }
        else{
            jPasswordField1.setEchoChar('*');
            jPasswordField2.setEchoChar('*');
        }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        //Back to login button
        dispose();
        Login l = new Login();
        l.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         //Create account Button
        String username = jTextField2.getText().trim();
        String fullname = jTextField1.getText().trim();
        String email = jTextField3.getText().trim();
        String password = String.valueOf(jPasswordField1.getPassword()).trim();
        String password2 = String.valueOf(jPasswordField2.getPassword()).trim();
        
        //accesses/create the file using the filepath given
        File file = new File(usersFilePath);
        
        try{
            //Checks if fields are blank
            if(username.equals("Username") || fullname.equals("Full Name") || email.equals("Email") || password.equals("password") || password2.equals("confirm password"))
            {
                //shown on the error message
                mesframe.jLabel1.setText("Signup Error");
                mesframe.jLabel2.setText("Fields must not be empty");
            }
            else
            {
                //writes on the file
                 FileWriter fw = new FileWriter(file, true);
                
                 //checks if the passwords match
                if(password.equals(password2))
                {
                    //checks if the username already exists
                    if(!checkUsername(username))
                    {
                        //written on the file
                        fw.write("\nUsername: " + username + "\n");
                        fw.write("Fullname: " + fullname + "\n");
                        fw.write("Email: " + email + "\n");
                        fw.write("Password: " + password + "\n");
                        fw.close(); 
                        
                        //shown on the error message
                        mesframe.jLabel1.setText("Signup");
                        mesframe.jLabel2.setText("Success, You may now Login");
                        
                        //exits the registry and returns to login
                        this.dispose();
                        Login l = new Login();
                        l.setVisible(true);
                        
                    }
                    else
                    {
                       //shown on the error message
                        mesframe.jLabel1.setText("Signup Error");
                        mesframe.jLabel2.setText("Username already taken");
                    }
                }
                else
                {
                    //shown on the error message
                    mesframe.jLabel1.setText("Signup Error");
                    mesframe.jLabel2.setText("Password does not match");
               }
            }
            
            mesframe.setVisible(true);
            
            
            }catch (IOException ex) {
                Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
            }
   
        
    }//GEN-LAST:event_jButton1ActionPerformed

    
    //written by the form editor of NetBeans
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
