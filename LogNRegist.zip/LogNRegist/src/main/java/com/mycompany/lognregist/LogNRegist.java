
package com.mycompany.lognregist;

/**
 *
 * @author MariaRufalethVibar
 */

public class LogNRegist {
    public static void main(String args[]){
       Login l = new Login();
       l.setVisible(true);

    }
}
